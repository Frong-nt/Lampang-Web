A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/PZyMrd.

 [Full explanatory article on my site](http://thenewcode.com/500/Use-YouTube-Videos-as-Fullscreen-Web-Page-Backgrounds).